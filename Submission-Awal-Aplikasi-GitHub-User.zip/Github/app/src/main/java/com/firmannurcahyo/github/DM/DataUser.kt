package com.firmannurcahyo.github.DM
//Firman Nurcahyo - 50421524 - Universitas Gunadarma - Dicoding Indonesia - Bangkit Academy
data class DataUser(
    val followers_url: String,
    val following_url: String,
    val avatar_url: String,
    val repos_url: String,
    val location: String,
    val company: String,
    val login: String,
    val name: String,

    val id: Int,
    val following: Int,
    val followers: Int,
    val public_repos: Int,
)