package com.firmannurcahyo.github.DM
//Firman Nurcahyo - 50421524 - Universitas Gunadarma - Dicoding Indonesia - Bangkit Academy
data class Responses(
    var items: ArrayList<User>,
    val incomplete_result: Boolean
)