package com.firmannurcahyo.github.DM
//Firman Nurcahyo - 50421524 - Universitas Gunadarma - Dicoding Indonesia - Bangkit Academy
data class User(
    val login: String,
    val id: Int,
    val avatar_url: String,
    val name: String,
    val incomplete_result: Boolean
)